package com.example.screenslidinglistener;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;

import com.example.screenslidinglistener.MyGestureListener.MyRightLeftListener;

public class MainActivity extends Activity {
	GestureDetector detector;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		detector = new GestureDetector(this, new MyGestureListener(
				new MyRightLeftListener() {
					/**
					 * ��ָ�������һ�����Ҫִ�еĴ���
					 */
					@Override
					public void onRight() {
						findViewById(R.id.activity_main_tv).setBackgroundColor(
								Color.GREEN);
					}

					/**
					 * ��ָ�������󻬶���Ҫִ�еĴ���
					 */
					@Override
					public void onLeft() {
						findViewById(R.id.activity_main_tv).setBackgroundColor(
								Color.RED);

					}

					/**
					 * ��ָ�������ϻ�����Ҫִ�еĴ���
					 */
					@Override
					public void onUp() {
						// TODO Auto-generated method stub
						findViewById(R.id.activity_main_tv).setBackgroundColor(
								Color.BLUE);
					}

					/**
					 * ��ָ�������»�����Ҫִ�еĴ���
					 */
					@Override
					public void onDown() {
						// TODO Auto-generated method stub
						findViewById(R.id.activity_main_tv).setBackgroundColor(
								Color.YELLOW);
					}
				}));
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		return detector.onTouchEvent(event);
	}
}
