package com.supercwn.player.bean;

/**
 *
 * @author Super南仔
 * @time 2016-9-19
 */
public class VideoListBean {

    private String titleName;
    private String videoUrl;
    private int id;

    public String getTitleName() {
        return titleName;
    }

    public void setTitleName(String titleName) {
        this.titleName = titleName;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
